module bitbucket.org/star2star/asteriskvoicebot/deepgram

go 1.24.0

toolchain go1.24.6

require (
	bitbucket.org/star2star/asteriskvoicebot/vproxy v0.0.0-20241105192705-0cb8ad96978d
	github.com/deepgram/deepgram-go-sdk v1.9.0
	golang.org/x/exp v0.0.0-20250813145105-42675adae3e6
)

replace bitbucket.org/star2star/asteriskvoicebot/vproxy => ../vproxy

require (
	github.com/dvonthenen/websocket v1.5.1-dyv.2 // indirect
	github.com/fatih/color v1.15.0 // indirect
	github.com/go-logr/logr v1.3.0 // indirect
	github.com/gorilla/schema v1.3.0 // indirect
	github.com/hokaccha/go-prettyjson v0.0.0-20211117102719-0474bc63780f // indirect
	github.com/mattn/go-colorable v0.1.13 // indirect
	github.com/mattn/go-isatty v0.0.17 // indirect
	github.com/wernerd/GoRTP v0.0.0-20191206100804-75c6a1c64532 // indirect
	golang.org/x/sys v0.6.0 // indirect
	k8s.io/klog/v2 v2.110.1 // indirect
)
