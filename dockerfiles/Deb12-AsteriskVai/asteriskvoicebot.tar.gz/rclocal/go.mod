module bitbucket.org/star2star/asteriskvoicebot/rclocal

go 1.23.1
