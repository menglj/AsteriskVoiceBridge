module bitbucket.org/star2star/asteriskvoicebot/vproxy

go 1.23.1

require github.com/wernerd/GoRTP v0.0.0-20191206100804-75c6a1c64532
