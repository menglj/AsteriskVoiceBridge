module bitbucket.org/star2star/asteriskvoicebot/ariman

go 1.24.0

toolchain go1.24.6

require (
	github.com/CyCoreSystems/ari/v6 v6.0.0-20250807101614-b97f61433a8f
	github.com/rotisserie/eris v0.5.4
	golang.org/x/exp v0.0.0-20250813145105-42675adae3e6
)

require (
	github.com/gogo/protobuf v1.3.2 // indirect
	github.com/oklog/ulid v1.3.1 // indirect
	golang.org/x/net v0.42.0 // indirect
)
